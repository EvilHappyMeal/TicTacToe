import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame implements ActionListener {

    //Boolean
    int scorePlayerOne = 0;
    int scorePlayerTwo = 0;
    int gameClicked = 0;

    boolean playerOne = true;
    boolean gameOver = false;
    boolean winnerOne = false;
    boolean winnerTwo = false;
    boolean draw = false;

    String playerSymbol;
    String player = null;


    //JPanel
    JPanel homepanel = new JPanel();
    JPanel inGamePanel = new JPanel();
    JPanel gameOverPanel = new JPanel();

    //JButton
    JButton startGameButton = new JButton();
    JButton exitGameButton = new JButton();

    JButton gameButtonOne = new JButton();
    JButton gameButtonTwo = new JButton();
    JButton gameButtonThree = new JButton();
    JButton gameButtonFour = new JButton();
    JButton gameButtonFive = new JButton();
    JButton gameButtonSix = new JButton();
    JButton gameButtonSeven = new JButton();
    JButton gameButtonEight = new JButton();
    JButton gameButtonNine = new JButton();

    JButton gameButtonMainmenu = new JButton();
    JButton nextRound = new JButton();

    //JLabel
    JLabel playerLabel = new JLabel();
    JLabel scoreLabel = new JLabel();
    JLabel winnerLabel = new JLabel();

    //Fonts
    Font myFont = new Font("Arial", Font.BOLD, 25);
    Font inGameFont = new Font("Arial", Font.BOLD, 20);

    //Colors
    Color myColor = new Color(120, 70, 70);
    Color homeButtonColor = new Color(150, 50, 50);

    //Border
    Border homeButtonBorder = BorderFactory.createLineBorder(new Color(200, 130, 0), 2);


    Home() {

        //JButton

        //startGameButton
        startGameButton.setVisible(true);
        startGameButton.setText("Spiel starten");
        startGameButton.setBounds(125, 140, 250, 50);
        startGameButton.setFocusable(false);
        startGameButton.setFont(myFont);
        startGameButton.setBackground(homeButtonColor);
        startGameButton.addActionListener(this);
        startGameButton.setBorder(homeButtonBorder);

        //exitGameButton
        exitGameButton.setVisible(true);
        exitGameButton.setText("Spiel verlassen");
        exitGameButton.setBounds(125, 210, 250, 50);
        exitGameButton.setFocusable(false);
        exitGameButton.setFont(myFont);
        exitGameButton.setBackground(homeButtonColor);
        exitGameButton.addActionListener(this);
        exitGameButton.setBorder(homeButtonBorder);

        //gameButtonOne
        gameButtonOne.setVisible(true);
        gameButtonOne.setBounds(85, 85, 100, 100);
        gameButtonOne.setFocusable(false);
        gameButtonOne.setFont(myFont);
        gameButtonOne.setBackground(homeButtonColor);
        gameButtonOne.setBorder(homeButtonBorder);
        gameButtonOne.addActionListener(this);
        gameButtonOne.setText("");

        //gameButtonTwo
        gameButtonTwo.setVisible(true);
        gameButtonTwo.setBounds(200, 85, 100, 100);
        gameButtonTwo.setFocusable(false);
        gameButtonTwo.setFont(myFont);
        gameButtonTwo.setBackground(homeButtonColor);
        gameButtonTwo.setBorder(homeButtonBorder);
        gameButtonTwo.addActionListener(this);
        gameButtonTwo.setText("");

        //gameButtonThree
        gameButtonThree.setVisible(true);
        gameButtonThree.setBounds(315, 85, 100, 100);
        gameButtonThree.setFocusable(false);
        gameButtonThree.setFont(myFont);
        gameButtonThree.setBackground(homeButtonColor);
        gameButtonThree.setBorder(homeButtonBorder);
        gameButtonThree.addActionListener(this);
        gameButtonThree.setText("");

        //gameButtonFour
        gameButtonFour.setVisible(true);
        gameButtonFour.setBounds(85, 200, 100, 100);
        gameButtonFour.setFocusable(false);
        gameButtonFour.setFont(myFont);
        gameButtonFour.setBackground(homeButtonColor);
        gameButtonFour.setBorder(homeButtonBorder);
        gameButtonFour.addActionListener(this);
        gameButtonFour.setText("");

        //gameButtonFive
        gameButtonFive.setVisible(true);
        gameButtonFive.setBounds(200, 200, 100, 100);
        gameButtonFive.setFocusable(false);
        gameButtonFive.setFont(myFont);
        gameButtonFive.setBackground(homeButtonColor);
        gameButtonFive.setBorder(homeButtonBorder);
        gameButtonFive.addActionListener(this);
        gameButtonFive.setText("");

        //gameButtonSix
        gameButtonSix.setVisible(true);
        gameButtonSix.setBounds(315, 200, 100, 100);
        gameButtonSix.setFocusable(false);
        gameButtonSix.setFont(myFont);
        gameButtonSix.setBackground(homeButtonColor);
        gameButtonSix.setBorder(homeButtonBorder);
        gameButtonSix.addActionListener(this);
        gameButtonSix.setText("");

        //gameButtonSeven
        gameButtonSeven.setVisible(true);
        gameButtonSeven.setBounds(85, 315, 100, 100);
        gameButtonSeven.setFocusable(false);
        gameButtonSeven.setFont(myFont);
        gameButtonSeven.setBackground(homeButtonColor);
        gameButtonSeven.setBorder(homeButtonBorder);
        gameButtonSeven.addActionListener(this);
        gameButtonSeven.setText("");

        //gameButtonEight
        gameButtonEight.setVisible(true);
        gameButtonEight.setBounds(200, 315, 100, 100);
        gameButtonEight.setFocusable(false);
        gameButtonEight.setFont(myFont);
        gameButtonEight.setBackground(homeButtonColor);
        gameButtonEight.setBorder(homeButtonBorder);
        gameButtonEight.addActionListener(this);
        gameButtonEight.setText("");

        //gameButtonNine
        gameButtonNine.setVisible(true);
        gameButtonNine.setBounds(315, 315, 100, 100);
        gameButtonNine.setFocusable(false);
        gameButtonNine.setFont(myFont);
        gameButtonNine.setBackground(homeButtonColor);
        gameButtonNine.setBorder(homeButtonBorder);
        gameButtonNine.addActionListener(this);
        gameButtonNine.setText("");

        //nextRound
        nextRound.setVisible(true);
        nextRound.setBounds(150, 200, 200, 50);
        nextRound.setFocusable(false);
        nextRound.setFont(myFont);
        nextRound.setBackground(homeButtonColor);
        nextRound.addActionListener(this);
        nextRound.setBorder(homeButtonBorder);
        nextRound.setText("Nächste Runde");

        //gameButtonMainmenu
        gameButtonMainmenu.setVisible(true);
        gameButtonMainmenu.setBounds(10, 85, 50, 50);
        gameButtonMainmenu.setFocusable(false);
        gameButtonMainmenu.setFont(new Font("Arial", Font.BOLD, 15));
        gameButtonMainmenu.setBackground(homeButtonColor);
        gameButtonMainmenu.setBorder(homeButtonBorder);
        gameButtonMainmenu.addActionListener(this);
        gameButtonMainmenu.setText("Menu");


        //JLabel

        //playerLabel
        playerLabel.setFont(inGameFont);
        playerLabel.setText(player);
        playerLabel.setVisible(true);
        playerLabel.setBounds(315, 10, 150, 50);
        playerLabel.setBorder(homeButtonBorder);
        playerLabel.setHorizontalAlignment(SwingConstants.CENTER);

        //scoreLabel
        scoreLabel.setFont(inGameFont);
        scoreLabel.setText("Spieler 1: " + scorePlayerOne + "       " + "Spieler 2: " + scorePlayerTwo);
        scoreLabel.setVisible(true);
        scoreLabel.setBounds(10, 10, 290, 50);
        scoreLabel.setBorder(homeButtonBorder);
        scoreLabel.setHorizontalAlignment(SwingConstants.CENTER);

        //winnerLabel
        winnerLabel.setFont(inGameFont);
        winnerLabel.setVisible(true);
        winnerLabel.setBounds(125, 50, 250, 50);
        winnerLabel.setBorder(homeButtonBorder);
        winnerLabel.setHorizontalAlignment(SwingConstants.CENTER);


        //JPanel

        //homePanel
        homepanel.setSize(500, 500);
        homepanel.setVisible(true);
        homepanel.setLayout(null);
        homepanel.setOpaque(true);
        homepanel.setFont(myFont);
        homepanel.setBackground(myColor);

        //inGamePanel
        inGamePanel.setSize(500, 500);
        inGamePanel.setVisible(false);
        inGamePanel.setLayout(null);
        inGamePanel.setOpaque(true);
        inGamePanel.setFont(myFont);
        inGamePanel.setBackground(myColor);

        //gameOverPanel
        gameOverPanel.setBounds(0, 0, 500, 500);
        gameOverPanel.setVisible(false);
        gameOverPanel.setLayout(null);
        gameOverPanel.setOpaque(true);
        gameOverPanel.setFont(myFont);
        gameOverPanel.setBackground(myColor);


        //Frame
        this.setLayout(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(500, 500);
        this.setResizable(false);
        this.setVisible(true);

        //add
        this.add(homepanel);
        this.add(inGamePanel);
        this.add(gameOverPanel);

        homepanel.add(startGameButton);
        homepanel.add(exitGameButton);

        inGamePanel.add(gameButtonOne);
        inGamePanel.add(gameButtonTwo);
        inGamePanel.add(gameButtonThree);
        inGamePanel.add(gameButtonFour);
        inGamePanel.add(gameButtonFive);
        inGamePanel.add(gameButtonSix);
        inGamePanel.add(gameButtonSeven);
        inGamePanel.add(gameButtonEight);
        inGamePanel.add(gameButtonNine);
        inGamePanel.add(scoreLabel);
        inGamePanel.add(playerLabel);
        inGamePanel.add(gameButtonMainmenu);

        gameOverPanel.add(winnerLabel);
        gameOverPanel.add(nextRound);

    }

    public void playerSelect() {    //Player 1 = O = false || Player 2 = X = true

        if (playerOne) {
            playerSymbol = "O";
            player = "Spieler 1 O";
        } else {
            playerSymbol = "X";
            player = "Spieler 2 X";
        }

        playerLabel.setText(player);
        playerLabel.updateUI();

        if (gameButtonOne.getText().equals("X") && gameButtonTwo.getText().equals("X") &&
                gameButtonThree.getText().equals("X")) {
            gameOver = true;
            winnerOne = true;
        }
        if (gameButtonFour.getText().equals("X") && gameButtonFive.getText().equals("X") &&
                gameButtonSix.getText().equals("X")) {
            gameOver = true;
            winnerOne = true;
        }
        if (gameButtonSeven.getText().equals("X") && gameButtonEight.getText().equals("X") &&
                gameButtonNine.getText().equals("X")) {
            gameOver = true;
            winnerOne = true;
        }

        if (gameButtonOne.getText().equals("X") && gameButtonFour.getText().equals("X") &&
                gameButtonSeven.getText().equals("X")) {
            gameOver = true;
            winnerOne = true;
        }
        if (gameButtonTwo.getText().equals("X") && gameButtonFive.getText().equals("X") &&
                gameButtonEight.getText().equals("X")) {
            gameOver = true;
            winnerOne = true;
        }
        if (gameButtonThree.getText().equals("X") && gameButtonSix.getText().equals("X") &&
                gameButtonNine.getText().equals("X")) {
            gameOver = true;
            winnerOne = true;
        }

        if (gameButtonOne.getText().equals("X") && gameButtonFive.getText().equals("X") &&
                gameButtonNine.getText().equals("X")) {
            gameOver = true;
            winnerOne = true;
        }
        if (gameButtonThree.getText().equals("X") && gameButtonFive.getText().equals("X") &&
                gameButtonSeven.getText().equals("X")) {
            gameOver = true;
            winnerOne = true;
        }


        if (gameButtonOne.getText().equals("O") && gameButtonTwo.getText().equals("O") &&
                gameButtonThree.getText().equals("O")) {
            gameOver = true;
            winnerTwo = true;
        }
        if (gameButtonFour.getText().equals("O") && gameButtonFive.getText().equals("O") &&
                gameButtonSix.getText().equals("O")) {
            gameOver = true;
            winnerTwo = true;
        }
        if (gameButtonSeven.getText().equals("O") && gameButtonEight.getText().equals("O") &&
                gameButtonNine.getText().equals("O")) {
            gameOver = true;
            winnerTwo = true;
        }

        if (gameButtonOne.getText().equals("O") && gameButtonFour.getText().equals("O") &&
                gameButtonSeven.getText().equals("O")) {
            gameOver = true;
            winnerTwo = true;
        }
        if (gameButtonTwo.getText().equals("O") && gameButtonFive.getText().equals("O") &&
                gameButtonEight.getText().equals("O")) {
            gameOver = true;
            winnerTwo = true;
        }
        if (gameButtonThree.getText().equals("O") && gameButtonSix.getText().equals("O") &&
                gameButtonNine.getText().equals("O")) {
            gameOver = true;
            winnerTwo = true;
        }

        if (gameButtonOne.getText().equals("O") && gameButtonFive.getText().equals("O") &&
                gameButtonNine.getText().equals("O")) {
            gameOver = true;
            winnerTwo = true;
        }
        if (gameButtonThree.getText().equals("O") && gameButtonFive.getText().equals("O") &&
                gameButtonSeven.getText().equals("O")) {
            gameOver = true;
            winnerTwo = true;
        }


        if (gameClicked >= 9){

            gameOver = true;
            draw = true;

        }

        if (gameOver) {

            gameOverPanel.setVisible(true);
            gameOverPanel.updateUI();
            inGamePanel.setVisible(false);
            inGamePanel.updateUI();

            if (winnerOne) {
                winnerLabel.setText("Spieler 1 hat gewonnen!");
                scorePlayerOne = scorePlayerOne + 1;
            }else if (winnerTwo){
                winnerLabel.setText("Spieler 2 hat gewonnen!");
                scorePlayerTwo = scorePlayerTwo + 1;
            }else if (draw){
                winnerLabel.setText("Unentschieden");
            }

            scoreLabel.setText("Spieler 1: " + scorePlayerOne + "       " + "Spieler 2: " + scorePlayerTwo);

            winnerLabel.updateUI();
            scoreLabel.updateUI();

        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == exitGameButton) {

            dispose();

        }

        if (e.getSource() == startGameButton) {

            homepanel.setVisible(false);
            inGamePanel.setVisible(true);

            if ((int) (Math.random() * 100) < 50)
                playerOne = true;                   //Player One
            else
                playerOne = false;                  //Player Two

            playerSelect();

        }

        if (e.getSource() == gameButtonOne) {

            playerSelect();

            if (gameButtonOne.getText().equals("")) {
                gameButtonOne.setText(playerSymbol);
                gameButtonOne.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }
        if (e.getSource() == gameButtonTwo) {

            playerSelect();

            if (gameButtonTwo.getText().equals("")) {
                gameButtonTwo.setText(playerSymbol);
                gameButtonTwo.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }
        if (e.getSource() == gameButtonThree) {

            playerSelect();

            if (gameButtonThree.getText().equals("")) {
                gameButtonThree.setText(playerSymbol);
                gameButtonThree.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }
        if (e.getSource() == gameButtonFour) {

            playerSelect();

            if (gameButtonFour.getText().equals("")) {
                gameButtonFour.setText(playerSymbol);
                gameButtonFour.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }
        if (e.getSource() == gameButtonFive) {

            playerSelect();

            if (gameButtonFive.getText().equals("")) {
                gameButtonFive.setText(playerSymbol);
                gameButtonFive.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }
        if (e.getSource() == gameButtonSix) {

            playerSelect();

            if (gameButtonSix.getText().equals("")) {
                gameButtonSix.setText(playerSymbol);
                gameButtonSix.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }
        if (e.getSource() == gameButtonSeven) {

            playerSelect();

            if (gameButtonSeven.getText().equals("")) {
                gameButtonSeven.setText(playerSymbol);
                gameButtonSeven.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }
        if (e.getSource() == gameButtonEight) {

            playerSelect();

            if (gameButtonEight.getText().equals("")) {
                gameButtonEight.setText(playerSymbol);
                gameButtonEight.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }
        if (e.getSource() == gameButtonNine) {

            playerSelect();

            if (gameButtonNine.getText().equals("")) {
                gameButtonNine.setText(playerSymbol);
                gameButtonNine.updateUI();

                playerOne = !playerOne;
                gameClicked ++;

                playerSelect();
            }
        }

        if (e.getSource() == nextRound){

            gameButtonOne.setText("");
            gameButtonTwo.setText("");
            gameButtonThree.setText("");
            gameButtonFour.setText("");
            gameButtonFive.setText("");
            gameButtonSix.setText("");
            gameButtonSeven.setText("");
            gameButtonEight.setText("");
            gameButtonNine.setText("");

            gameButtonOne.updateUI();
            gameButtonTwo.updateUI();
            gameButtonThree.updateUI();
            gameButtonFour.updateUI();
            gameButtonFive.updateUI();
            gameButtonSix.updateUI();
            gameButtonSeven.updateUI();
            gameButtonEight.updateUI();
            gameButtonNine.updateUI();

            gameOverPanel.setVisible(false);
            gameOverPanel.updateUI();
            inGamePanel.setVisible(true);
            inGamePanel.updateUI();

            winnerOne = false;
            winnerTwo = false;
            gameOver = false;
            gameClicked = 0;

            if ((int) (Math.random() * 100) < 50)
                playerOne = true;                   //Player One
            else
                playerOne = false;                  //Player Two

            playerSelect();

        }
        if (e.getSource() == gameButtonMainmenu){

            gameButtonOne.setText("");
            gameButtonTwo.setText("");
            gameButtonThree.setText("");
            gameButtonFour.setText("");
            gameButtonFive.setText("");
            gameButtonSix.setText("");
            gameButtonSeven.setText("");
            gameButtonEight.setText("");
            gameButtonNine.setText("");

            gameButtonOne.updateUI();
            gameButtonTwo.updateUI();
            gameButtonThree.updateUI();
            gameButtonFour.updateUI();
            gameButtonFive.updateUI();
            gameButtonSix.updateUI();
            gameButtonSeven.updateUI();
            gameButtonEight.updateUI();
            gameButtonNine.updateUI();

            gameOverPanel.setVisible(false);
            gameOverPanel.updateUI();
            inGamePanel.setVisible(true);
            inGamePanel.updateUI();

            winnerOne = false;
            winnerTwo = false;
            gameOver = false;
            gameClicked = 0;

            inGamePanel.setVisible(false);
            homepanel.setVisible(true);

            inGamePanel.updateUI();
            homepanel.updateUI();

        }

    }
}
